package com.sopt.assignment04.post

data class PostWriteBoardResponse(
    val status : String,
    val message : String
)